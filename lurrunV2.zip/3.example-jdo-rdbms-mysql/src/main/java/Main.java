

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jdo.Extent;
import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Query;
import javax.jdo.Transaction;


import entities.*;
public class Main {

	public static void main(String[] args) {
		/**		
			Game game = new Game("HL3",100,20);				
			MySql db = new MySql(); 
			
			db.storeGame(game);									
			
			Game game1=db.getGame("HL3");
			System.out.println(game1.toString());
		*/
		

    	System.out.println("Starting ....");
        // Create a PersistenceManagerFactory for this datastore
        PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("datanucleus.properties");

        System.out.println("DataNucleus AccessPlatform with JDO");
        System.out.println("===================================");

        // Persistence of a Company and a Game.
        PersistenceManager pm = pmf.getPersistenceManager();
        Transaction tx=pm.currentTransaction();
        try
        {
            tx.begin();
            System.out.println("Persisting Companys");
            Company Company = new Company("Valve");
            Game Game = new Game("HL3",12.0,0.5);
            pm.makePersistent(Company);
            pm.makePersistent(Game);
 
            tx.commit();
            System.out.println("Company and Game have been persisted");
        }
        finally
        {
            if (tx.isActive())
            {
                tx.rollback();
            }
            pm.close();
        }
        System.out.println("");

        // Basic Extent of all Companys
        pm = pmf.getPersistenceManager();
        tx = pm.currentTransaction();
        try
        {
            tx.begin();
            System.out.println("Retrieving Extent for Companys");
            Extent<Company> e = pm.getExtent(Company.class, true);
            Iterator<Company> iter = e.iterator();
            while (iter.hasNext())
            {
                Object obj = iter.next();
                System.out.println(">  " + obj);
            }
            tx.commit();
        }
        catch (Exception e)
        {
            System.out.println("Exception thrown during retrieval of Extent : " + e.getMessage());
        }
        finally
        {
            if (tx.isActive())
            {
                tx.rollback();
            }
            pm.close();
        }
        System.out.println("");

        // Perform some query operations
        pm = pmf.getPersistenceManager();
        tx = pm.currentTransaction();
       /**
        * ESTO FALTA ES PARA HACER UPDATES PERO NO SE MUY BIEN COMO SE USA
        * 
        try
        {
            tx.begin();
            System.out.println("Executing Query for Companys with price below 150.00");
            Extent<Company> e=pm.getExtent(Company.class,true);
            Query<Company> q=pm.newQuery(e, "price < 150.00");
            q.setOrdering("price ascending");
                        
            for (Company Company : (List<Company>)q.execute()) {
            	System.out.println(">  " + Company);
            	if (Company instanceof Game)
                {
                    Game b = (Game)Company;
                    // Give an example of an update
                    b.setPrice(5);
                    System.out.println("This Game has been reduced in price!");
                }
    
            }

            tx.commit();
        }
        finally
        {
            if (tx.isActive())
            {
                tx.rollback();
            }
            pm.close();
        }
        System.out.println("");
        */
 
        

        // Clean out the database
        pm = pmf.getPersistenceManager();
        tx = pm.currentTransaction();
        try
        {
            tx.begin();
            System.out.println("Deleting all Companys from persistence");
            Query<Company> q = pm.newQuery(Company.class);
            long numberInstancesDeleted = q.deletePersistentAll();
            System.out.println("Deleted " + numberInstancesDeleted + " Companys");
            
            System.out.println("Deleting all Games from persistence");
            Query<Game> w = pm.newQuery(Game.class);
            
            
            ;

            tx.commit();
        }
        finally
        {
            if (tx.isActive())
            {
                tx.rollback();
            }
            pm.close();
        }

        
        pm = pmf.getPersistenceManager();
        tx = pm.currentTransaction();
        try
        {
            tx.begin();
            System.out.println("Retrieving Extent for Companys");
            Extent<Company> e = pm.getExtent(Company.class, true);
            Iterator<Company> iter = e.iterator();
            while (iter.hasNext())
            {
                Object obj = iter.next();
                System.out.println(">  " + obj);
            }
            tx.commit();
        }
        catch (Exception e)
        {
            System.out.println("Exception thrown during retrieval of Extent : " + e.getMessage());
        }
        finally
        {
            if (tx.isActive())
            {
                tx.rollback();
            }
            pm.close();
        }
        System.out.println("");
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        System.out.println("");
        System.out.println("End of Tutorial");
		pmf.close();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
