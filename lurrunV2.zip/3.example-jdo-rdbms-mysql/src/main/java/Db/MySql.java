package Db;

import entities.*;

import javax.jdo.*;


import java.util.ArrayList;
import java.util.Iterator;

public class MySql implements IMySql  {

}	
