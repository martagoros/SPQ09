package Db;



import entities.Game;
import java.util.ArrayList;
public interface IMySql {
	//ArrayList<Matrices> list = new ArrayList<Matrices>();
	//list.add( new Matrices(1,1,10) );
	/**	
public void storeGame(Game g);
public void deleteGame(Game g);
public Game getGame(String name);
public  ArrayList<Game> getAllGames();

*/
}